﻿using System;

class FloatDouble
{
    static void Main()
    {
        float var1 = 34.567839023f;
        float var2 = 12.345f;
        float var3 = 8923.1234857f;
        float var4 = 3456.091f;

        Console.WriteLine(var1);
        Console.WriteLine(var2);
        Console.WriteLine(var3);
        Console.WriteLine(var4);
    }
}