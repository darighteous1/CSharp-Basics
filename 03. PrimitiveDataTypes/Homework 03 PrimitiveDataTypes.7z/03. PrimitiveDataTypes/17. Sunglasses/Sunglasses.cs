﻿using System;
using System.Text;

class Sunglasses
{
    static void Main()
    {
        int glassesHeight = int.Parse(Console.ReadLine());
        int frameWidth = 2 * glassesHeight;
        int lenseHeight = glassesHeight - 2;
        int lenseWidth = 2*glassesHeight - 2;
        int bridgeWidth = glassesHeight;

        Console.OutputEncoding = System.Text.Encoding.UTF8;
        
        char asterisk = '\u002A';
        char slash = '\u2215';
        char verticalLine = '\u007C';
        string space = new string (' ', glassesHeight);
        string frame = new string(asterisk, frameWidth);
        
        string lense = new string(slash, lenseWidth);
        string bridge = new string(verticalLine, bridgeWidth);

        //the upper frame5
        Console.WriteLine("{0}{1}{0}", frame, space);
        
        // lenses
        if (lenseHeight == 1)
        {
            Console.WriteLine("{0}{1}{0}{2}{0}{1}{0}", asterisk, lense, bridge);
        }
        else
        {
            for (int i = 1; i < glassesHeight - 2; i++)
            {


                if (i == (lenseHeight + 1) / 2)
                {
                    Console.WriteLine("{0}{1}{0}{2}{0}{1}{0}", asterisk, lense, bridge); //bridge
                }

                Console.WriteLine("{0}{1}{0}{2}{0}{1}{0}", asterisk, lense, space);
            }
        }
        //the lower frame
        Console.WriteLine("{0}{1}{0}", frame, space);
    }
}