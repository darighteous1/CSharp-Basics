﻿using System;

class EmployeeData
{
    static void Main()
    {
        string firstName = "Гошо";
        string lastName = "от Почивка";
        byte age = 32;
        char gender = 'm';
        ulong personalID = 8306112507;
        int employeeNumber = 27560001;
        
        Console.WriteLine(firstName);
        Console.WriteLine(lastName);
        Console.WriteLine(age);
        Console.WriteLine(gender);
        Console.WriteLine(personalID);
        Console.WriteLine(employeeNumber);
    }
}