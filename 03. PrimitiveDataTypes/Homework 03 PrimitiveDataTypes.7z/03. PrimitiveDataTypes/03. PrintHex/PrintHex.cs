﻿using System;

class Program
{
        static void Main()
        {
            int num = 0xFE;
            Console.WriteLine(num);
        }
}