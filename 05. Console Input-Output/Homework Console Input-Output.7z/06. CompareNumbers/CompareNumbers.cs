﻿using System;

class CompareNumbers
{
    static void Main()
    {
        double x = double.Parse(Console.ReadLine());
        double y = double.Parse(Console.ReadLine());
        Console.WriteLine(x>y? x : y);
    }
}