﻿using System;

class DefinePoints
{
    static void Main()
    {
        Point a = new Point(20, 30);
        Point b = new Point(0, 100);
    }
}