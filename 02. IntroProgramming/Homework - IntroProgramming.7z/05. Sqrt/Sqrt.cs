﻿using System;

class Sqrt
{
    static void Main()
    {
        Console.WriteLine(Math.Sqrt(12345)); // Math.Sqrt() method returns the square root of the number in the brackets 
    }
}