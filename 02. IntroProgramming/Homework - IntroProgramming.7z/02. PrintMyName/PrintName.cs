﻿using System;

class PrintName
{
    static void Main()
    {
        Console.WriteLine("Hi, my name is Slim Shady!");
    }
}