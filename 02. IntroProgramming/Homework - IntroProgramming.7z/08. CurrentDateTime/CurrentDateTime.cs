﻿using System;

class CurrentDateTime
{
    static void Main()
    {
        Console.WriteLine(DateTime.Now); //the .Now property gets a DateTime object that is set to the current date and time on this computer, expressed as the local time.
    }
}