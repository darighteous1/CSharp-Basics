﻿using System;

class FirstLastName
{
    static void Main()
    {
        Console.WriteLine("Гошо");
        Console.WriteLine("от Почивка");
    }
}